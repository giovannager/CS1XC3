/**
 * @file main.c
 * @author Giovanna Gerada (you@domain.com)
 * @brief makes use of the functions and data types defined in student.h, student.c, course.h, and course.c
 * @version 0.1
 * @date 2022-04-06
 * 
 * @copyright Copyright (c) 2022
 * 
 */


#include <stdlib.h> 
#include <stdio.h>
#include <string.h>
#include "time.h"
#include "course.h"

/**
 * @brief creates a course, randomly generates students to be enrolled in the course, and prints the course, top student, number of passing students, and students who passed the course
 * 
 * @return int 
 */
int main()
{
  srand((unsigned) time(NULL)); // generates a random unsigned integer based on the current time

  Course *MATH101 = calloc(1, sizeof(Course)); // dynamically allocates space, intiallized to 0, for a single course MATH101
  strcpy(MATH101->name, "Basics of Mathematics");
  strcpy(MATH101->code, "MATH 101");

  // generates 20 random students with 8 grades and enrolls them in MATH101
  for (int i = 0; i < 20; i++) 
    enroll_student(MATH101, generate_random_student(8));
  
  print_course(MATH101);

  // finds and prints the top student in MATH101
  Student *student;
  student = top_student(MATH101);
  printf("\n\nTop student: \n\n");
  print_student(student);

  // prints the total number of passing students as well as the students who have passed
  int total_passing;
  Student *passing_students = passing(MATH101, &total_passing);
  printf("\nTotal passing: %d\n", total_passing);
  printf("\nPassing students:\n\n");
  for (int i = 0; i < total_passing; i++) print_student(&passing_students[i]); // iterates through the students who've passed, printing each one
  
  return 0;
}