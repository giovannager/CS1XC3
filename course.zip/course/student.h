/**
 * @file student.h
 * @author Giovanna Gerada (you@domain.com)
 * @brief creates the Student type and pre-defines functions add_grade, average, print_student, and generate_random_student
 * @version 0.1
 * @date 2022-04-06
 * 
 * @copyright Copyright (c) 2022
 * 
 */

/**
 * @brief Student type stores a student with fields first_name, last_name, id, grades, and num_grades
 * 
 */
typedef struct _student 
{ 
  char first_name[50]; /**< the student's first name */
  char last_name[50]; /**< the student's last name */
  char id[11]; /**< the student's 10 character id */
  double *grades; /**< the student's grades*/
  int num_grades; /**< the number of grades that the student has*/
} Student;

// pre-defining functions to be later constructed in student.c
void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student* generate_random_student(int grades); 
