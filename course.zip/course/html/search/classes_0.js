var searchData=
[
  ['_5fcourse_27',['_course',['../struct__course.html',1,'']]],
  ['_5fstudent_28',['_student',['../struct__student.html',1,'']]]
];
