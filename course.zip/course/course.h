/**
 * @file course.h
 * @author Giovanna Gerada (you@domain.com)
 * @brief creates the Course type and predefines functions enroll_student, print_course, top_student, and passing
 * @version 0.1
 * @date 2022-04-06
 * 
 * @copyright Copyright (c) 2022
 * 
 */

#include "student.h"
#include <stdbool.h>

/**
 * @brief Course type stores a course with fields name, code, students, and total_students
 * 
 */
typedef struct _course 
{
  char name[100]; /**< The course's name*/
  char code[10]; /**< The course's code */
  Student *students; /**< The students of the Student type who are in the course*/
  int total_students; /**< the total number of students in the course */
} Course;

// pre-defining functions to be later constructed in course.c
void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);


