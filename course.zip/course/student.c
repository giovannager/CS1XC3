/**
 * @file student.c
 * @author Giovanna Gerada (you@domain.com)
 * @brief 
 * @version 0.1
 * @date 2022-04-06
 * 
 * @copyright Copyright (c) 2022
 * 
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "student.h"


/**
 * @brief adds a passed in grade to the dynamically allocated array of a passed in student's grades; num_grades
 * 
 * @param student 
 * @param grade 
 */
void add_grade(Student* student, double grade)
{
  student->num_grades++;
  // allocates new memory which is initialized to 0 to hold the grade if the student currently has no grades in num_grades
  if (student->num_grades == 1) student->grades = calloc(1, sizeof(double)); 
  // if the student already has grades in num_grades, memory is reallocated to make space for this new grade
  else 
  {
    student->grades = 
      realloc(student->grades, sizeof(double) * student->num_grades);
  }
  student->grades[student->num_grades - 1] = grade;
}


/**
 * @brief calculates and returns the average grade of a passed in student
 * 
 * @param student 
 * @return double 
 */
double average(Student* student)
{
  if (student->num_grades == 0) return 0; // returns 0 if the student has no grades

  double total = 0;
  for (int i = 0; i < student->num_grades; i++) total += student->grades[i]; // stores the sum of each of the student's grades in total
  return total / ((double) student->num_grades); // returns the total divided by the number of grades; the average
}


/**
 * @brief formats the printing of a student, showing their name, id, grades, and average
 * 
 * @param student 
 */
void print_student(Student* student)
{
  printf("Name: %s %s\n", student->first_name, student->last_name);
  printf("ID: %s\n", student->id);
  printf("Grades: ");
  // loops through the students grades and prints each one to two decimal places
  for (int i = 0; i < student->num_grades; i++) 
    printf("%.2f ", student->grades[i]);
  printf("\n");
  printf("Average: %.2f\n\n", average(student));
}

/**
 * @brief randomly generates a student, choosing their name randomly out of a list of 24 different first names and last names, also randomizing the numbers for their ID and grades
 *
 * 
 * @param grades 
 * @return Student* 
 */
Student* generate_random_student(int grades)
{
  char first_names[][24] = 
    {"Shahrzad", "Leonti", "Alexa", "Ricardo", "Clara", "Berinhard", "Denzel",
     "Ali", "Nora", "Malcolm", "Muhammad", "Madhu", "Jaiden", "Helena", "Diana",
     "Julie", "Omar", "Yousef",  "Amir", "Wang", "Li", "Zhang", "Fen", "Lin"};

  char last_names[][24] = 
   {"Chen", "Yang", "Zhao", "Huang", "Brown", "Black", "Smith", "Williams", 
    "Jones", "Miller", "Johnson", "Davis", "Abbas", "Ali", "Bakir", "Ismat", 
    "Khalid", "Wahed", "Taleb", "Hafeez", "Hadid", "Lopez", "Gonzalez", "Moore"};
 
  Student *new_student = calloc(1, sizeof(Student)); // Dynamically allocates space on the heap, which is set to 0, for a new student of student type

  strcpy(new_student->first_name, first_names[rand() % 24]);
  strcpy(new_student->last_name, last_names[rand() % 24]);

  // at each iteration, generates a random number from 0-9, converts it to an ascii character and stores it in the next position of the student's id 
  for (int i = 0; i < 10; i++) new_student->id[i] = (char) ((rand() % 10) + 48);
  new_student->id[10] = '\0';

  // at each iteration, generates a random number from 0-74, adds 25 to it, and stores the value in the students grades using the add_grade function
  for (int i = 0; i < grades; i++) 
  {
    add_grade(new_student, (double) (25 + (rand() % 75)));
  }

  return new_student;
}